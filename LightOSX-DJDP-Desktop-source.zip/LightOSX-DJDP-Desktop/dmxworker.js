'use strict';
// Native DMX output thread: runs in its own thread so the app's UI can never stall the DMX signal.
// It keeps re-sending the latest frame at a steady rate, like a hardware DMX controller.
// Runs either as an Electron utility process (default, crash-isolated) or as a worker thread (fallback / tests).
let wt = null; try { wt = require('worker_threads').parentPort; } catch (e) {}
const parentPort = wt || { postMessage: m => process.parentPort.postMessage(m), on: (ev, cb) => process.parentPort.on('message', e => cb(e.data)) };
const { SerialPort, SerialPortMock } = require('serialport');
const mock = !!process.env.LOSX_MOCK_SERIAL;
let port = null, running = false, cfg = { mode: 'break', hz: 40, breakUs: 100, mabUs: 12, rts: false }, frame = new Uint8Array(513), n = 513, frames = 0, errors = 0, lastErr = '', conseq = 0;
const post = (t, o) => parentPort.postMessage(Object.assign({ t }, o || {}));
const sleep = ms => new Promise(r => setTimeout(r, Math.max(0, ms)));
const spinUs = us => { const end = process.hrtime.bigint() + BigInt(Math.round(us * 1000)); while (process.hrtime.bigint() < end); };
const setLog = []; const setP = o => new Promise((res, rej) => port.set(o, e => { if (mock && setLog.length < 40) setLog.push(!!o.brk); e ? rej(e) : res(); }));
const write = b => new Promise((res, rej) => { let d = false; const ok = () => { if (!d) { d = true; clearTimeout(t); res(); } }, bad = e => { if (!d) { d = true; clearTimeout(t); rej(e); } }; const t = setTimeout(() => bad(new Error('serial write timed out')), 2000); port.write(b, e => (e ? bad(e) : port.drain(e2 => (e2 ? bad(e2) : ok())))); });
function proPacket() { const L = n, pk = Buffer.alloc(L + 5); pk[0] = 0x7E; pk[1] = 6; pk[2] = L & 255; pk[3] = L >> 8; Buffer.from(frame.buffer, 0, L).copy(pk, 4); pk[L + 4] = 0xE7; return pk; }
async function loop() {
  running = true; let next = Date.now(), lastStat = Date.now();
  while (running) {
    try {
      if (cfg.mode === 'pro') await write(proPacket());
      else { await setP({ brk: true, rts: cfg.rts, dtr: true }); spinUs(cfg.breakUs); await setP({ brk: false, rts: cfg.rts, dtr: true }); spinUs(cfg.mabUs); await write(Buffer.from(frame.buffer, 0, n)); }
      frames++; conseq = 0;
    } catch (e) { errors++; conseq++; lastErr = e && e.message || String(e); post('error', { msg: lastErr }); if (conseq >= 6) { running = false; post('lost', { msg: lastErr }); return; } await sleep(30); }
    if (Date.now() - lastStat > 1000) { lastStat = Date.now(); post('stat', { frames, errors, last: lastErr }); }
    const minMs = (n * 44 + cfg.breakUs + cfg.mabUs) / 1000 + 1.2; // a full frame cannot be sent faster than the wire allows
    next += Math.max(1000 / cfg.hz, minMs); const w = next - Date.now(); if (w > 0) await sleep(w); else next = Date.now();
  }
}
async function open(m) {
  cfg = Object.assign(cfg, { mode: m.mode, hz: m.hz || 40, breakUs: m.breakUs || 100, mabUs: m.mabUs || 12, rts: !!m.rts });
  const opts = { path: m.path, baudRate: m.baud, dataBits: 8, stopBits: m.stop, parity: 'none', autoOpen: false };
  if (mock) { const { MockBinding } = require('@serialport/binding-mock'); MockBinding.createPort(m.path, { echo: false, record: true }); port = new SerialPortMock(opts); } else port = new SerialPort(opts);
  await new Promise((res, rej) => port.open(e => (e ? rej(e) : res())));
  port.on('error', e => post('error', { msg: e.message })); port.on('close', () => { if (running) { running = false; post('closed', { msg: 'port closed' }); } });
  // match the browser path: serialport's set() would otherwise force RTS high, which some interfaces read as "transmitter off"
  try { await new Promise(res => port.set({ brk: false, rts: cfg.rts, dtr: true }, () => res())); } catch (e) {}
  frame[0] = 0; loop(); return true;
}
parentPort.on('message', async m => {
  try {
    if (m.t === 'list') { const l = await SerialPort.list(); post('list', { ports: l.map(p => ({ path: p.path, manufacturer: p.manufacturer || '', serialNumber: p.serialNumber || '', vendorId: p.vendorId || '', productId: p.productId || '', friendlyName: p.friendlyName || p.pnpId || '', locationId: p.locationId || p.pnpId || '' })) }); }
    else if (m.t === 'open') { await open(m); post('opened', { id: m.rid }); }
    else if (m.t === 'frame') { const d = m.data, k = Math.min(512, d.length); frame = new Uint8Array(513); frame[0] = 0; frame.set(d.subarray ? d.subarray(0, k) : d.slice(0, k), 1); n = k + 1; }
    else if (m.t === 'config') { if (m.hz) cfg.hz = m.hz; if (m.breakUs) cfg.breakUs = m.breakUs; if (m.mabUs) cfg.mabUs = m.mabUs; if (m.rts != null) cfg.rts = !!m.rts; }
    else if (m.t === 'debug') { const rec = port && port.port && port.port.recording; post('debug', { rec: rec ? Array.from(rec.subarray(rec.length - n, rec.length - n + 12)) : null, recLen: rec ? rec.length : 0, sets: setLog.slice(0, 8) }); }
    else if (m.t === 'close') { running = false; await sleep(60); try { if (port && port.isOpen) await new Promise(r => port.close(() => r())); } catch (e) {} post('bye'); }
  } catch (e) { if (m && m.t === 'list') post('list', { ports: [] }); else post('openfail', { id: m && m.rid, msg: e && e.message || String(e) }); }
});
