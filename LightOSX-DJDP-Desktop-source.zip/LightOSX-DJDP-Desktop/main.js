'use strict';
process.env.UV_THREADPOOL_SIZE = '16'; // more I/O threads: a stuck serial call can no longer starve everything else
const { app, BrowserWindow, ipcMain, dialog, Menu, powerSaveBlocker, session, desktopCapturer, shell, utilityProcess, screen } = require('electron');
const path = require('path'), fs = require('fs'), dgram = require('dgram'), { Worker } = require('worker_threads'), { OpenRGB } = require('./openrgb');
// Keep DMX running at full speed even when the window is covered or minimised
['disable-renderer-backgrounding', 'disable-background-timer-throttling', 'disable-backgrounding-occluded-windows'].forEach(f => app.commandLine.appendSwitch(f));
if (process.platform === 'linux') { app.commandLine.appendSwitch('enable-experimental-web-platform-features'); app.commandLine.appendSwitch('enable-web-bluetooth'); } // Web Bluetooth is switched off by default in Chromium on Linux
if (process.platform === 'linux') app.commandLine.appendSwitch('no-sandbox'); // the app only loads its own local page; avoids AppArmor/userns sandbox failures
const exeDir = path.dirname(process.execPath);
if (fs.existsSync(path.join(exeDir, 'portable.txt'))) app.setPath('userData', path.join(exeDir, 'LightOSX-data'));
if (!app.requestSingleInstanceLock()) app.quit();
app.commandLine.appendSwitch('enable-usermedia-screen-capturing'); // lets the classic desktop-loopback request work as a fallback
let bleHint = null; // names of the Bluetooth strip(s) to reconnect to without asking
let win = null, rgb = null, rgbKey = '', blocker = 0, capLast = '';
const settingsFile = () => path.join(app.getPath('userData'), 'LightOSX-settings.json');
// ---- small log file (LightOSX-log.txt in the data folder) so crashes and freezes leave a trace ----
const logFile = () => path.join(app.getPath('userData'), 'LightOSX-log.txt');
function logLine(m) { try { const f = logFile(); fs.mkdirSync(path.dirname(f), { recursive: true }); try { if (fs.statSync(f).size > 400000) fs.writeFileSync(f, ''); } catch (x) {} fs.appendFileSync(f, new Date().toISOString() + '  ' + m + '\n'); } catch (x) {} }
process.on('uncaughtException', e => { logLine('uncaughtException: ' + (e && e.stack || e)); });
process.on('unhandledRejection', e => { logLine('unhandledRejection: ' + (e && e.stack || e)); });
let lastReload = 0;
const pick = (title, items, detail) => dialog.showMessageBox(win, { type: 'question', title, message: title, detail: detail || '', buttons: items.slice(0, 14).concat(['Cancel']), cancelId: Math.min(items.length, 14), noLink: true }).then(r => (r.response >= Math.min(items.length, 14) ? -1 : r.response));
ipcMain.on('app-version', e => { e.returnValue = app.getVersion(); });
ipcMain.on('settings-path', e => { e.returnValue = settingsFile(); });
ipcMain.on('settings-load', e => { try { e.returnValue = fs.readFileSync(settingsFile(), 'utf8'); } catch (x) { e.returnValue = ''; } });
ipcMain.on('settings-save', (e, text) => { try { fs.mkdirSync(path.dirname(settingsFile()), { recursive: true }); const tmp = settingsFile() + '.tmp'; fs.writeFileSync(tmp, text); fs.renameSync(tmp, settingsFile()); } catch (x) { console.error('settings save failed', x.message); } });
const sock = dgram.createSocket('udp4'); sock.on('error', () => {}); sock.bind(0, () => { try { sock.setBroadcast(true); sock.setMulticastTTL(8); } catch (e) {} });
ipcMain.on('udp', (e, ip, port, data) => { try { sock.send(Buffer.from(data), port, ip, () => {}); } catch (x) {} });
ipcMain.handle('rgb-connect', async (e, host, port) => { try { const key = (host || '127.0.0.1') + ':' + (port || 6742); if (rgb && rgb.sock && rgbKey === key) return { ok: true, devices: rgb.devices.map(d => ({ index: d.index, name: d.name, leds: d.leds })) }; rgbKey = key; if (rgb) rgb.close(); rgb = new OpenRGB(); rgb.onclose = () => { if (win && !win.isDestroyed()) win.webContents.send('rgb-closed'); }; return { ok: true, devices: await rgb.connect(host || '127.0.0.1', port || 6742) }; } catch (x) { return { ok: false, error: x.code === 'ECONNREFUSED' ? 'OpenRGB is not running with its SDK Server started (OpenRGB > SDK Server > Start Server).' : String(x.message || x) }; } });
ipcMain.on('rgb-set', (e, idx, r, g, b) => { if (rgb) rgb.setColor(idx, r, g, b); });
ipcMain.on('rgb-disconnect', () => { if (rgb) { rgb.close(); rgb = null; } });

// ---- native DMX interfaces (serial) run in worker threads ----
const dmxWorkers = new Map(); let capMode = 'pick';
// Serial/USB code runs in a separate helper process (utilityProcess). If it ever crashes or hangs, only that helper dies:
// the window keeps running and the app reconnects. Falls back to a worker thread if helpers are unavailable.
function spawnDmx(tag) {
  const file = path.join(__dirname, 'dmxworker.js');
  try {
    const p = utilityProcess.fork(file, [], { serviceName: 'LightOSX DMX', stdio: 'pipe', env: Object.assign({}, process.env, { UV_THREADPOOL_SIZE: '8' }) });
    if (p.stderr) p.stderr.on('data', d => logLine('dmx[' + tag + '] ' + String(d).trim().slice(0, 400)));
    return { p, kind: 'proc', post: m => p.postMessage(m), kill: () => { try { p.kill(); } catch (x) {} }, on: (ev, cb) => p.on(ev, cb) };
  } catch (e) {
    logLine('utilityProcess unavailable, using a worker thread: ' + e.message);
    const w = new Worker(file);
    return { p: w, kind: 'thread', post: m => w.postMessage(m), kill: () => { try { w.terminate(); } catch (x) {} }, on: (ev, cb) => w.on(ev, ev === 'exit' ? c => cb(c) : cb) };
  }
}
const sendWin = (ch, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); };
let listCache = null, listBusy = null;
ipcMain.handle('dmx-list', () => {
  if (listCache && Date.now() - listCache.t < 1500) return listCache.v;
  if (listBusy) return listBusy;
  listBusy = new Promise(resolve => {
    let done = false, h = null; const fin = v => { if (done) return; done = true; clearTimeout(tm); if (h) h.kill(); listCache = { t: Date.now(), v }; listBusy = null; resolve(v); };
    const tm = setTimeout(() => { logLine('serial port scan timed out'); fin([]); }, 6000);
    try { h = spawnDmx('list'); h.on('message', m => { if (m && m.t === 'list') fin(m.ports || []); }); h.on('exit', () => fin([])); h.post({ t: 'list' }); } catch (e) { logLine('list failed: ' + e.message); fin([]); }
  });
  return listBusy;
});
ipcMain.handle('dmx-open', (e, id, o) => new Promise(resolve => {
  logLine('dmx open ' + JSON.stringify({ id, path: o.path, mode: o.mode, baud: o.baud, stop: o.stop, hz: o.hz, rts: o.rts }));
  const old = dmxWorkers.get(id); if (old) { try { old.post({ t: 'close' }); } catch (x) {} old.kill(); dmxWorkers.delete(id); }
  let done = false; const w = spawnDmx(id); w.closing = false; dmxWorkers.set(id, w); const rid = Math.random();
  const fin = r => { if (!done) { done = true; clearTimeout(tm); resolve(r); } };
  const tm = setTimeout(() => { logLine('serial open timed out for ' + id); fin({ ok: false, error: 'The serial port did not open in time.' }); w.closing = true; w.kill(); if (dmxWorkers.get(id) === w) dmxWorkers.delete(id); }, 9000);
  w.on('message', m => { if (m.t === 'opened') fin({ ok: true }); else if (m.t === 'openfail') { logLine('serial open failed: ' + m.msg); fin({ ok: false, error: m.msg }); w.closing = true; w.kill(); if (dmxWorkers.get(id) === w) dmxWorkers.delete(id); } else if (m.t !== 'bye' && m.t !== 'list') sendWin('dmx-event', id, m); });
  w.on('error', er => { logLine('dmx helper error: ' + (er && er.message || er)); fin({ ok: false, error: String(er && er.message || er) }); });
  w.on('exit', code => { if (dmxWorkers.get(id) === w) dmxWorkers.delete(id); if (!w.closing) { logLine('dmx helper for ' + id + ' stopped unexpectedly (code ' + code + ')'); fin({ ok: false, error: 'The DMX helper stopped (code ' + code + '). Try again.' }); sendWin('dmx-event', id, { t: 'lost', msg: 'the DMX helper stopped (code ' + code + ')' }); } });
  w.post(Object.assign({ t: 'open', rid }, o));
}));
ipcMain.on('dmx-frame', (e, id, data) => { const w = dmxWorkers.get(id); if (w) w.post({ t: 'frame', data }); });
ipcMain.on('dmx-config', (e, id, o) => { const w = dmxWorkers.get(id); if (w) w.post(Object.assign({ t: 'config' }, o)); });
ipcMain.on('dmx-close', (e, id) => { const w = dmxWorkers.get(id); if (w) { w.closing = true; w.post({ t: 'close' }); setTimeout(() => { w.kill(); if (dmxWorkers.get(id) === w) dmxWorkers.delete(id); }, 400); } });
ipcMain.handle('capture-mode', (e, m) => { capMode = m; capLast = ''; return true; });
ipcMain.handle('capture-status', () => capLast);
/* Show tab: songs are remembered by file path and read again from disk. Only audio and video files, and nothing over 2 GB. */
ipcMain.handle('ble-hint', (e, h) => { bleHint = h && Array.isArray(h.names) ? { names: h.names.map(n => String(n).toLowerCase()), auto: !!h.auto, t: Date.now() } : null; return true; });
ipcMain.handle('gesture', () => { try { return win.webContents.executeJavaScript('window.__gestureRun && window.__gestureRun()', true); } catch (e) { return null; } }); // runs a page function as if the user had clicked (Web Bluetooth needs that)
// HA-BEGIN: small local web API so Home Assistant (or anything on the network) can press pads, black out, start the chase, send a scene
const haHttp = require('http'), haOs = require('os'); let haSrv = null, haCfg = { enabled: false, port: 8765, token: '', lan: true };
function haStop() { if (haSrv) { try { haSrv.close(); } catch (e) {} haSrv = null; } }
function haStart() {
  haStop(); if (!haCfg.enabled || !haCfg.token) return;
  haSrv = haHttp.createServer(async (req, res) => {
    const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
    try {
      const u = new URL(req.url, 'http://x'), key = (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || u.searchParams.get('token') || ''; if (key !== haCfg.token) return send(401, { error: 'bad key' });
      const parts = u.pathname.split('/').filter(Boolean); if (parts[0] !== 'api') return send(404, { error: 'not found' });
      let body = ''; for await (const c of req) { body += c; if (body.length > 20000) break; } let args = {}; try { args = body ? JSON.parse(body) : {}; } catch (e) {}
      const cmd = parts[1] || 'status', a = Object.assign({}, args, { id: decodeURIComponent(parts[2] || args.id || ''), action: parts[3] || args.action || parts[2] || '' }); if (!win) return send(503, { error: 'window not ready' });
      const r = await win.webContents.executeJavaScript('window.__ha && window.__ha(' + JSON.stringify(cmd) + ',' + JSON.stringify(a) + ')'); send(r && r.error ? 400 : 200, r == null ? { ok: true } : r);
    } catch (e) { send(500, { error: String(e.message || e) }); }
  });
  haSrv.on('error', e => { logLine('home assistant API: ' + e.message); haSrv = null; });
  haSrv.listen(haCfg.port, haCfg.lan ? '0.0.0.0' : '127.0.0.1', () => logLine('home assistant API listening on port ' + haCfg.port));
}
ipcMain.handle('ha-config', async (e, c) => { haCfg = { enabled: !!(c && c.enabled), port: Math.min(65535, Math.max(1024, parseInt(c && c.port, 10) || 8765)), token: String((c && c.token) || ''), lan: !(c && c.lan === false) }; haStart(); await new Promise(r => setTimeout(r, 250)); const ips = []; try { Object.values(haOs.networkInterfaces()).forEach(l => (l || []).forEach(i => { if (i.family === 'IPv4' && !i.internal) ips.push(i.address); })); } catch (x) {} return { running: !!haSrv && haSrv.listening, port: haCfg.port, ips }; });
// HA-END
ipcMain.handle('fs-read', async (e, p) => { if (typeof p !== 'string' || !/\.(mp3|wav|flac|ogg|oga|opus|m4a|aac|aif|aiff|wma|mp4|m4v|mov|mkv|webm|avi)$/i.test(p)) throw new Error('not a media file'); const st = await fs.promises.stat(p); if (!st.isFile() || st.size > 2147483000) throw new Error('too large'); return await fs.promises.readFile(p); });
// LLM-IPC-BEGIN: local AI scene generator talks to a model server (Ollama, LM Studio, llama.cpp ...) from here, so no browser CORS limits apply
ipcMain.handle('llm-request', async (e, o) => {
  if (!o || typeof o.url !== 'string' || !/^https?:\/\//i.test(o.url)) return { ok: false, status: 0, text: '', error: 'bad address' };
  const ctl = new AbortController(), ms = Math.min(Math.max(+o.timeout || 120000, 3000), 900000), tm = setTimeout(() => ctl.abort(), ms), get = o.method === 'GET';
  try { const r = await fetch(o.url, { method: get ? 'GET' : 'POST', headers: Object.assign(get ? {} : { 'Content-Type': 'application/json' }, o.headers || {}), body: get ? undefined : (typeof o.body === 'string' ? o.body : JSON.stringify(o.body || {})), signal: ctl.signal }); const text = await r.text(); return { ok: r.ok, status: r.status, text: text.slice(0, 4000000) }; }
  catch (err) { return { ok: false, status: 0, text: '', error: err && err.name === 'AbortError' ? 'timed out after ' + Math.round(ms / 1000) + ' s' : String((err && err.cause && err.cause.code) || (err && err.message) || err) }; }
  finally { clearTimeout(tm); }
});
// LLM-IPC-END
ipcMain.handle('screens-list', () => { const pid = screen.getPrimaryDisplay().id; return screen.getAllDisplays().map((d, i) => ({ id: String(d.id), label: 'Display ' + (i + 1) + ' · ' + d.bounds.width + '×' + d.bounds.height + (d.id === pid ? ' (main)' : '') + (d.label ? ' · ' + d.label : ''), x: d.bounds.x, y: d.bounds.y, w: d.bounds.width, h: d.bounds.height, primary: d.id === pid })); });
ipcMain.on('sound-settings', () => { try { if (process.platform === 'win32') shell.openExternal('ms-settings:sound'); else if (process.platform === 'darwin') shell.openExternal('x-apple.systempreferences:com.apple.preference.sound'); } catch (x) {} });
function createWindow() {
  win = new BrowserWindow({ width: 1440, height: 900, backgroundColor: '#080b12', title: 'LightOSX by DJDP', icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true, webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false } });
  win.loadFile(path.join(__dirname, 'LightOSX-DJDP.html'));
  if (process.env.LOSX_SELFTEST) win.webContents.on('console-message', (e, l, msg) => { if (/OFL|rror/.test(msg)) console.log('RENDERER ' + msg); });
  if (process.env.LOSX_SELFTEST) win.webContents.on('did-finish-load', () => setTimeout(async () => { try { const r = await win.webContents.executeJavaScript("(async()=>{LOSX_NATIVE.saveSettings(JSON.stringify({app:'LightOSX',data:{selftest:1}}));const ev=[];LOSX_NATIVE.dmx.onEvent((id,e)=>ev.push(e.t+':'+(e.frames||'')));const ports=await LOSX_NATIVE.dmx.list();const o=await LOSX_NATIVE.dmx.open('t1',{path:'/dev/MOCKX',mode:'break',baud:250000,stop:2,hz:30,breakUs:100,mabUs:12});LOSX_NATIVE.dmx.frame('t1',new Uint8Array(512).fill(9));await new Promise(r=>setTimeout(r,1600));LOSX_NATIVE.dmx.close('t1');return JSON.stringify({native:!!window.LOSX_NATIVE,version:LOSX_NATIVE.version,boot:window.__boot,compatGone:!document.getElementById('compat'),brands:document.querySelector('#fx-brand').options.length,tabs:document.querySelectorAll('.tabbtn').length,serial:'serial' in navigator,usb:!!navigator.usb,midi:!!navigator.requestMIDIAccess,loaded:LOSX_NATIVE.loadSettings().length>0,path:LOSX_NATIVE.settingsPath(),dmxPorts:Array.isArray(ports),dmxOpen:o,dmxEvents:ev.slice(0,4),sysAudioBtn:!!document.getElementById('aud-sys-btn'),outSettingsBtn:!document.getElementById('aud-out-set').hidden})})()"); console.log('SELFTEST ' + r); } catch (x) { console.log('SELFTEST ERROR ' + x.message); } app.quit(); }, 4000));

  // Screen-output windows (virtual 'Screen' fixtures): opened by the page with window.open, placed full screen on the chosen display
  win.webContents.setWindowOpenHandler(({ frameName, features }) => {
    if (!/^losx-screen/.test(frameName || '')) return { action: 'allow' };
    const mm = /lxdisplay=(\d+)/.exec(features || ''); let d = mm && screen.getAllDisplays().find(x => String(x.id) === mm[1]); if (!d) { try { d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()); } catch (x) {} } // no (or a missing) chosen display: open on the display where the mouse is
    const o = { backgroundColor: '#000', autoHideMenuBar: true, title: 'LightOSX screen', webPreferences: { backgroundThrottling: false, contextIsolation: true, nodeIntegration: false } };
    if (d) Object.assign(o, { x: d.bounds.x, y: d.bounds.y, width: d.bounds.width, height: d.bounds.height, frame: false, fullscreen: process.platform !== 'darwin' });
    return { action: 'allow', overrideBrowserWindowOptions: o };
  });
  win.webContents.on('did-create-window', (child, det) => { try { if (/^losx-screen/.test(det.frameName || '')) { child.webContents.on('before-input-event', (ev, inp) => { try { if (inp.type === 'keyDown' && (inp.key === 'Escape' || ((inp.control || inp.meta) && String(inp.key).toLowerCase() === 'w'))) { ev.preventDefault(); child.close(); } } catch (x) {} }); child.setMenuBarVisibility(false); if (process.platform === 'darwin' && det.options && det.options.frame === false) child.setSimpleFullScreen(true); logLine('screen window opened'); } } catch (x) {} });
  const ses = win.webContents.session;

  ses.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const mode = capMode, sysMode = mode !== 'pick';
      let sources = [];
      try { sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: 1, height: 1 }, fetchWindowIcons: false }); }
      catch (e) { logLine('desktopCapturer failed: ' + e.message); if (sysMode) { try { sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: 1, height: 1 } }); } catch (x) { logLine('desktopCapturer retry failed: ' + x.message); } } }
      logLine('display-media request: mode=' + (sysMode ? 'system' : 'pick') + ' sources=' + sources.length + ' audioRequested=' + request.audioRequested);
      if (!sources.length) { await new Promise(r => setTimeout(r, 500)); try { sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: 1, height: 1 }, fetchWindowIcons: false }); } catch (x) {} logLine('capture sources retry: ' + sources.length); }
      if (!sources.length) { capLast = 'nosrc'; return callback({}); }
      const audio = (process.platform === 'win32' && request.audioRequested !== false) ? 'loopback' : undefined;
      if (sysMode) { capMode = 'pick'; let own = ''; try { own = win ? win.getMediaSourceId() : ''; } catch (x) {} const scr = sources.find(s => s.id.startsWith('screen')), ownS = own && sources.find(s => s.id === own), v = mode === 'system-screen' ? (scr || ownS || sources[0]) : (ownS || scr || sources[0]); /* the video is never used (the page stops it at once); LightOSX's own window is the capture source that starts reliably on Windows, the screen is the second try */ logLine('capture source: ' + mode + ' -> ' + v.name + ' (' + v.id + ')'); capLast = 'ok'; return callback(audio ? { video: v, audio } : { video: v }); }
      const items = sources.slice(0, 13), i = await pick('Choose what to capture', items.map(s => (s.id.startsWith('screen') ? 'Screen: ' : 'Window: ') + s.name), process.platform === 'win32' ? 'On Windows the audio captured is the whole system output (everything this PC plays), whichever source you pick. For a single tab, use Capture Tab in a normal browser.' : 'Audio capture of a screen or window depends on your system. If there is no sound, use a Monitor input from the Mic / Sound Input list.');
      if (i < 0) { capLast = 'cancel'; return callback({}); } capLast = 'ok'; callback(audio ? { video: items[i], audio } : { video: items[i] });
    } catch (e) { logLine('display-media handler error: ' + (e && e.message)); capLast = 'error'; try { callback({}); } catch (x) {} }
  }, { useSystemPicker: process.platform === 'darwin' });
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(true)); ses.setPermissionCheckHandler(() => true); ses.setDevicePermissionHandler(() => true);
  ses.on('select-serial-port', (event, ports, wc, cb) => { event.preventDefault(); if (!ports.length) return cb(''); if (ports.length === 1) return cb(ports[0].portId); pick('Choose the DMX interface', ports.map(p => `${p.displayName || p.portName} (${p.portName})`), 'Several serial devices were found.').then(i => cb(i >= 0 ? ports[i].portId : '')); });
  ses.on('select-usb-device', (event, devs, wc, cb) => { event.preventDefault(); if (!devs.length) return cb(''); if (devs.length === 1) return cb(devs[0].deviceId); pick('Choose the USB device', devs.map(d => d.productName || ('USB ' + d.vendorId + ':' + d.productId))).then(i => cb(i >= 0 ? devs[i].deviceId : '')); });
  try { if (ses.setBluetoothPairingHandler) ses.setBluetoothPairingHandler((d, cb) => { try { cb({ confirmed: d.pairingKind === 'confirm' || d.pairingKind === 'confirmPin' }); } catch (x) {} }); } catch (x) {}
  let bt = null;
  win.webContents.on('select-bluetooth-device', (event, devs, cb) => {
    event.preventDefault();
    const hint = bleHint && Date.now() - bleHint.t < 30000 ? bleHint : null, hit = hint && hint.names.length ? devs.find(d => hint.names.includes(String(d.deviceName || '').toLowerCase())) : null;
    if (hit) { if (bt) { clearTimeout(bt.t); bt = null; } try { cb(hit.deviceId); } catch (x) {} logLine('bluetooth: connected to the remembered strip ' + hit.deviceName); return; }
    if (bt) { bt.list = devs; return; }
    bt = { list: devs, cb, t0: Date.now(), t: null, auto: !!(hint && hint.auto) };
    const finish = async () => {
      const b = bt; if (!b) return; const l = b.list;
      if (b.auto) { bt = null; try { b.cb(''); } catch (x) {} logLine('bluetooth: the remembered strip was not found'); return; }
      let i = -1; try { i = await pick('Choose the Bluetooth device', l.map(d => d.deviceName || d.deviceId), 'Make sure the strip is powered on and not connected to a phone app.'); } catch (x) { i = -1; }
      bt = null; try { b.cb(i >= 0 && l[i] ? l[i].deviceId : ''); } catch (x) {}
    };
    const tick = () => { if (!bt) return; const age = Date.now() - bt.t0; if (bt.list.length && age >= 3500 && !bt.auto) return finish(); if (age >= 9000) { const b = bt; bt = null; try { b.cb(''); } catch (x) {} logLine('bluetooth: no devices found in 9 s'); return; } bt.t = setTimeout(tick, 500); };
    bt.t = setTimeout(tick, 500);
  });
  win.webContents.on('unresponsive', () => logLine('window became unresponsive'));
  win.webContents.on('responsive', () => logLine('window responsive again'));
  win.webContents.on('render-process-gone', (e, d) => { logLine('render process gone: ' + d.reason + ' (code ' + d.exitCode + ')'); if (d.reason !== 'clean-exit' && Date.now() - lastReload > 10000) { lastReload = Date.now(); setTimeout(() => { try { if (win && !win.isDestroyed()) win.webContents.reload(); } catch (x) {} }, 400); } });
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: 'View', submenu: [{ role: 'reload' }, { role: 'togglefullscreen' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }, { role: 'toggleDevTools' }] }, { label: 'Help', submenu: [{ label: 'Open log / settings folder', click: () => { try { shell.showItemInFolder(fs.existsSync(logFile()) ? logFile() : settingsFile()); } catch (x) {} } }] }, { role: 'quit' }]));
}
app.on('child-process-gone', (e, d) => d.reason !== 'killed' && logLine('child process gone: ' + d.type + ' ' + d.reason + ' (code ' + d.exitCode + ')'));
app.whenReady().then(() => { logLine('start v' + app.getVersion() + ' ' + process.platform + ' ' + process.arch + ' electron ' + process.versions.electron); blocker = powerSaveBlocker.start('prevent-display-sleep'); createWindow(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); }); });
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => { dmxWorkers.forEach(w => { w.closing = true; w.kill(); }); if (rgb) rgb.close(); if (blocker) powerSaveBlocker.stop(blocker); app.quit(); });
