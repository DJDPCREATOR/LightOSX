'use strict';
// Minimal OpenRGB SDK client (protocol up to v3). Used by the desktop app to light PC RGB devices.
const net = require('net');
const u32 = n => { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0); return b; };
function parseController(b, ver, index) {
  let o = 4; const r32 = () => { const v = b.readUInt32LE(o); o += 4; return v; }, r16 = () => { const v = b.readUInt16LE(o); o += 2; return v; };
  const str = () => { const n = r16(); const s = b.toString('utf8', o, o + Math.max(0, n - 1)); o += n; return s; };
  o += 4; const name = str(); if (ver >= 1) str(); str(); str(); str(); str();
  const nm = r16(); o += 4;
  for (let m = 0; m < nm; m++) { str(); o += 16; if (ver >= 3) o += 8; o += 12; if (ver >= 3) o += 4; o += 8; const nc = r16(); o += 4 * nc; }
  const nz = r16(); for (let z = 0; z < nz; z++) { str(); o += 16; const ml = r16(); o += ml; }
  const leds = r16();
  return { index, name, leds };
}
class OpenRGB {
  constructor() { this.sock = null; this.buf = Buffer.alloc(0); this.waiters = []; this.version = 0; this.devices = []; this.onclose = null; this.cache = {}; }
  _send(dev, id, payload) { if (!this.sock) return; const h = Buffer.alloc(16); h.write('ORGB', 0, 'ascii'); h.writeUInt32LE(dev, 4); h.writeUInt32LE(id, 8); h.writeUInt32LE(payload.length, 12); this.sock.write(Buffer.concat([h, payload])); }
  _req(dev, id, payload, reply, ms = 3000) { return new Promise((res, rej) => { const w = { id: reply === undefined ? id : reply, res }; this.waiters.push(w); this._send(dev, id, payload); setTimeout(() => { const i = this.waiters.indexOf(w); if (i >= 0) { this.waiters.splice(i, 1); rej(new Error('OpenRGB did not answer')); } }, ms); }); }
  _data(d) {
    this.buf = Buffer.concat([this.buf, d]);
    while (this.buf.length >= 16) {
      if (this.buf.toString('ascii', 0, 4) !== 'ORGB') { this.buf = Buffer.alloc(0); return; }
      const size = this.buf.readUInt32LE(12); if (this.buf.length < 16 + size) return;
      const id = this.buf.readUInt32LE(8), payload = this.buf.subarray(16, 16 + size); this.buf = this.buf.subarray(16 + size);
      const i = this.waiters.findIndex(w => w.id === id); if (i >= 0) this.waiters.splice(i, 1)[0].res(Buffer.from(payload));
    }
  }
  async connect(host = '127.0.0.1', port = 6742) {
    await new Promise((res, rej) => { const s = net.createConnection({ host, port }); this.sock = s; s.setNoDelay(true); s.once('connect', res); s.once('error', rej); s.on('data', d => this._data(d)); s.on('close', () => { this.sock = null; if (this.onclose) this.onclose(); }); s.on('error', () => {}); });
    this._send(0, 50, Buffer.from('LightOSX DJDP\0'));
    const sv = await this._req(0, 40, u32(3), 40, 1200).catch(() => null);
    this.version = sv && sv.length >= 4 ? Math.min(3, sv.readUInt32LE(0)) : 0;
    const cnt = (await this._req(0, 0, Buffer.alloc(0), 0)).readUInt32LE(0); this.devices = [];
    for (let i = 0; i < cnt; i++) { const d = await this._req(i, 1, this.version >= 1 ? u32(this.version) : Buffer.alloc(0), 1); this.devices.push(parseController(d, this.version, i)); this._send(i, 1100, Buffer.alloc(0)); }
    return this.devices.map(d => ({ index: d.index, name: d.name, leds: d.leds }));
  }
  setColor(idx, r, g, b) {
    const key = r + ',' + g + ',' + b; const list = idx < 0 ? this.devices : this.devices.filter(d => d.index === idx);
    list.forEach(d => { if (this.cache[d.index] === key) return; this.cache[d.index] = key; const n = d.leds, p = Buffer.alloc(6 + 4 * n); p.writeUInt32LE(p.length, 0); p.writeUInt16LE(n, 4); for (let i = 0; i < n; i++) { p[6 + i * 4] = r; p[7 + i * 4] = g; p[8 + i * 4] = b; } this._send(d.index, 1050, p); });
  }
  close() { try { if (this.sock) this.sock.destroy(); } catch (e) {} this.sock = null; }
}
module.exports = { OpenRGB, parseController };
