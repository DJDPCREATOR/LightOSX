'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');
let rgbClosed = null, dmxCb = null; ipcRenderer.on('rgb-closed', () => { if (rgbClosed) rgbClosed(); }); ipcRenderer.on('dmx-event', (e, id, ev) => { if (dmxCb) dmxCb(id, ev); });
contextBridge.exposeInMainWorld('LOSX_NATIVE', {
  desktop: true, platform: process.platform, version: ipcRenderer.sendSync('app-version'), electron: process.versions.electron,
  udp: (ip, port, data) => ipcRenderer.send('udp', ip, port, data),
  screens: () => ipcRenderer.invoke('screens-list'),
  pathFor: f => { try { return webUtils.getPathForFile(f) || ''; } catch (e) { return ''; } }, readFile: p => ipcRenderer.invoke('fs-read', p), llm: o => ipcRenderer.invoke('llm-request', o), bleHint: h => ipcRenderer.invoke('ble-hint', h), gesture: () => ipcRenderer.invoke('gesture'), haConfig: c => ipcRenderer.invoke('ha-config', c),
  loadSettings: () => ipcRenderer.sendSync('settings-load'), saveSettings: t => ipcRenderer.send('settings-save', t), settingsPath: () => ipcRenderer.sendSync('settings-path'),
  captureMode: m => ipcRenderer.invoke('capture-mode', m), captureStatus: () => ipcRenderer.invoke('capture-status'), openSoundSettings: () => ipcRenderer.send('sound-settings'),
  rgb: { connect: (host, port) => ipcRenderer.invoke('rgb-connect', host, port), setColor: (idx, r, g, b) => ipcRenderer.send('rgb-set', idx, r, g, b), disconnect: () => ipcRenderer.send('rgb-disconnect'), onClosed: cb => { rgbClosed = cb; } },
  dmx: { list: () => ipcRenderer.invoke('dmx-list'), open: (id, o) => ipcRenderer.invoke('dmx-open', id, o), frame: (id, data) => ipcRenderer.send('dmx-frame', id, data), config: (id, o) => ipcRenderer.send('dmx-config', id, o), close: id => ipcRenderer.send('dmx-close', id), onEvent: cb => { dmxCb = cb; } }
});
