// Verifies the native DMX thread against a mock serial port: break sequence, frame content, refresh rate, loss detection.
process.env.LOSX_MOCK_SERIAL = '1';
const { Worker } = require('worker_threads'); const path = require('path');
const w = new Worker(path.join(__dirname, '..', 'dmxworker.js')); const msgs = []; let opened = false;
w.on('message', m => { msgs.push(m); if (m.t === 'opened') opened = true; });
w.on('error', e => console.log('WORKER ERROR', e.message));
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  w.postMessage({ t: 'open', rid: 1, path: '/dev/MOCK1', mode: 'break', baud: 250000, stop: 2, hz: 30, breakUs: 100, mabUs: 12 }); await sleep(300);
  const d = new Uint8Array(512); d[0] = 255; d[1] = 128; d[9] = 7; w.postMessage({ t: 'frame', data: d }); await sleep(1300);
  w.postMessage({ t: 'debug' }); await sleep(100);
  const st = msgs.filter(m => m.t === 'stat').pop(), dbg = msgs.find(m => m.t === 'debug');
  console.log('opened', opened, '| frames after ~1.6s', st && st.frames, '(≈20-30 per second here; the mock is slower than real hardware pacing)', '| sequence of break set calls', JSON.stringify(dbg.sets), '(expect true,false,true,false…)');
  console.log('last frame first bytes', JSON.stringify(dbg.rec), '(expect start code 0 then 255,128,0…)', '| bytes', dbg.recLen);
  w.postMessage({ t: 'config', hz: 10 }); await sleep(100); const f0 = msgs.filter(m => m.t === 'stat').pop().frames; await sleep(1100); const f1 = msgs.filter(m => m.t === 'stat').pop().frames; console.log('after config 10 Hz, frames in ~1.1s:', f1 - f0, '(expect ~10)');
  const ok = opened && st && st.frames > 25 && dbg.sets[0] === true && dbg.sets[1] === false && dbg.rec[0] === 0 && dbg.rec[1] === 255 && dbg.rec[2] === 128 && dbg.rec[10] === 7 && st.frames > 25;
  console.log(ok ? 'DMX WORKER OK' : 'DMX WORKER MISMATCH'); w.postMessage({ t: 'close' }); await sleep(300); process.exit(0);
})();
