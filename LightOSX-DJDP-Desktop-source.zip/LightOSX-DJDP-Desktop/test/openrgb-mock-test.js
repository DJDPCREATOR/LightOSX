// verify the OpenRGB client against a mock server implementing the documented wire format
const net = require('net'); const { OpenRGB } = require('../openrgb.js');
const hdr = (dev, id, p) => { const h = Buffer.alloc(16); h.write('ORGB', 0); h.writeUInt32LE(dev, 4); h.writeUInt32LE(id, 8); h.writeUInt32LE(p.length, 12); return Buffer.concat([h, p]); };
const s16 = s => { const b = Buffer.alloc(2 + s.length + 1); b.writeUInt16LE(s.length + 1, 0); b.write(s, 2); return b; };
const u32 = n => { const b = Buffer.alloc(4); b.writeUInt32LE(n); return b; }, u16 = n => { const b = Buffer.alloc(2); b.writeUInt16LE(n); return b; };
function controller(ver, name, leds) {
  const parts = [u32(0), s16(name), s16('Vendor'), s16('desc'), s16('1.0'), s16('serial'), s16('loc'), u16(2), u32(0)];
  for (const m of ['Direct', 'Static']) { parts.push(s16(m), u32(1), u32(0), u32(0), u32(0)); if (ver >= 3) parts.push(u32(0), u32(100)); parts.push(u32(1), u32(1), u32(0)); if (ver >= 3) parts.push(u32(50)); parts.push(u32(0), u32(1), u16(1), u32(0xFF)); }
  parts.push(u16(1), s16('Zone1'), u32(0), u32(leds), u32(leds), u32(leds), u16(0));
  parts.push(u16(leds)); for (let i = 0; i < leds; i++) parts.push(s16('LED' + i), u32(0));
  parts.push(u16(leds)); for (let i = 0; i < leds; i++) parts.push(u32(0));
  const body = Buffer.concat(parts); return Buffer.concat([u32(body.length + 4), body]);
}
const got = []; let sv = 3;
const srv = net.createServer(sock => { let buf = Buffer.alloc(0); sock.on('data', d => { buf = Buffer.concat([buf, d]); while (buf.length >= 16) { const size = buf.readUInt32LE(12); if (buf.length < 16 + size) break; const dev = buf.readUInt32LE(4), id = buf.readUInt32LE(8), p = buf.subarray(16, 16 + size); buf = buf.subarray(16 + size);
  if (id === 40) sock.write(hdr(0, 40, u32(sv))); else if (id === 0) sock.write(hdr(0, 0, u32(2))); else if (id === 1) sock.write(hdr(dev, 1, controller(Math.min(3, p.readUInt32LE(0)), dev ? 'Keyboard' : 'Mobo', dev ? 104 : 12))); else if (id === 1050) got.push({ dev, n: p.readUInt16LE(4), c: [p[6], p[7], p[8]] }); else if (id === 1100) got.push({ custom: dev }); } }); });
srv.listen(0, '127.0.0.1', async () => { const port = srv.address().port, c = new OpenRGB(); try { const devs = await c.connect('127.0.0.1', port); console.log('devices', JSON.stringify(devs)); c.setColor(-1, 255, 0, 128); await new Promise(r => setTimeout(r, 150)); console.log('updates', JSON.stringify(got)); const ok = devs.length === 2 && devs[0].leds === 12 && devs[1].leds === 104 && got.filter(x => x.n).length === 2; console.log(ok ? 'OPENRGB CLIENT OK' : 'OPENRGB MISMATCH'); } catch (e) { console.log('ERR', e.message); } c.close(); srv.close(); });
